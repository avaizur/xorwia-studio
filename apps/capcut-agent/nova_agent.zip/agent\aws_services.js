const { S3Client, PutObjectCommand } = require('@aws-sdk/client-s3');
const { getSignedUrl } = require('@aws-sdk/s3-request-presigner');
const { BedrockRuntimeClient, InvokeModelCommand } = require('@aws-sdk/client-bedrock-runtime');
const fs = require('fs');

// Initialize AWS Clients (Relies on AWS Credentials being set in ENV or EC2/Lambda Role)
// Default region should match your AWS setup (e.g., us-east-1)
const REGION = process.env.AWS_REGION || 'us-east-1';
const BUCKET_NAME = process.env.AWS_S3_BUCKET || 'nova-studio-clips'; // Change to your deployed bucket name

const s3Client = new S3Client({ region: REGION });
const bedrockClient = new BedrockRuntimeClient({ region: REGION });

/**
 * Uploads a local file to S3 and returns a temporary presigned download URL.
 */
async function uploadToS3AndGetUrl(filePath, fileName) {
    if (!fs.existsSync(filePath)) {
        throw new Error(`File not found: ${filePath}`);
    }

    try {
        console.log(`[AWS] Uploading ${fileName} to S3 bucket ${BUCKET_NAME}...`);
        const fileStream = fs.createReadStream(filePath);

        const uploadParams = {
            Bucket: BUCKET_NAME,
            Key: `clips/${fileName}`,
            Body: fileStream,
            ContentType: 'video/mp4'
        };

        const command = new PutObjectCommand(uploadParams);
        await s3Client.send(command);

        console.log(`[AWS] Generating presigned URL for ${fileName}...`);
        // Generate a URL that expires in 1 hour (3600 seconds)
        // This is highly secure and saves money!
        const presignedUrl = await getSignedUrl(s3Client, command, { expiresIn: 3600 });
        
        return presignedUrl;
    } catch (error) {
        console.error('[AWS S3 Error]', error);
        throw new Error('Failed to upload video: ' + error.message);
    }
}

/**
 * Uses Amazon Bedrock (Claude 3 Haiku) to analyze a video transcript and return hook recommendations.
 */
async function analyzeTranscriptWithBedrock(transcriptText) {
    console.log(`[AWS] Analyzing ${transcriptText.length} characters with Bedrock...`);
    
    const prompt = `You are an expert social media content analyzer. Read this video transcript and identify the 3 best "hooks" or engaging moments that would make great 15-60 second vertical clips (like TikTok or Reels).
    
Transcript:
${transcriptText}

Format your response as a JSON array of objects, with each object having properties: 
- "time" (estimated start second as an integer, if possible, or 0 if unknown)
- "reason" (why this is a good hook, max 50 chars)
- "tag" (a short 1-2 word category, e.g., "Viral Start", "Hot Take").
Return ONLY valid JSON.`;

    try {
        // Using Anthropic Claude 3 Haiku for blazing fast, incredibly cheap text analysis
        const payload = {
            anthropic_version: "bedrock-2023-05-31",
            max_tokens: 500,
            temperature: 0.7,
            messages: [{ role: "user", content: prompt }]
        };

        const command = new InvokeModelCommand({
            modelId: "anthropic.claude-3-haiku-20240307-v1:0",
            contentType: "application/json",
            accept: "application/json",
            body: JSON.stringify(payload)
        });

        const response = await bedrockClient.send(command);
        const decodedResponse = new TextDecoder().decode(response.body);
        const jsonResponse = JSON.parse(decodedResponse);
        
        const contentText = jsonResponse.content[0].text;
        
        // Extract JSON array from text to prevent extra dialogue breaking the app
        const jsonMatch = contentText.match(/\[[\s\S]*\]/);
        if (jsonMatch) {
            return JSON.parse(jsonMatch[0]);
        } else {
            throw new Error("Could not parse JSON from Bedrock response");
        }
        
    } catch (error) {
        console.error('[AWS Bedrock Error]', error);
        // Fallback gracefully if Bedrock isn't enabled in the user's AWS account yet
        return [
            { time: 10, reason: "Fallback: Standard Hook", tag: "Default" },
            { time: 60, reason: "Please enable Bedrock Claude 3 Haiku to activate AI", tag: "Setup Required" }
        ];
    }
}

module.exports = {
    uploadToS3AndGetUrl,
    analyzeTranscriptWithBedrock
};
